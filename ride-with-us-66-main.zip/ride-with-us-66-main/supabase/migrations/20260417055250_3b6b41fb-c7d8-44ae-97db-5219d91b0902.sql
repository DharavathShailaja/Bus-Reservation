-- Roles enum and table (security best practice)
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users view own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins view all roles" ON public.user_roles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Buses
CREATE TABLE public.buses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  operator TEXT NOT NULL,
  bus_type TEXT NOT NULL DEFAULT 'AC Seater',
  total_seats INTEGER NOT NULL DEFAULT 36,
  amenities TEXT[] DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.buses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view buses" ON public.buses FOR SELECT USING (true);
CREATE POLICY "Admins manage buses" ON public.buses FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Routes
CREATE TABLE public.routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES public.buses(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  destination TEXT NOT NULL,
  departure_time TIME NOT NULL,
  arrival_time TIME NOT NULL,
  duration_minutes INTEGER NOT NULL DEFAULT 360,
  price NUMERIC(10,2) NOT NULL,
  travel_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_routes_search ON public.routes(source, destination, travel_date);

ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view routes" ON public.routes FOR SELECT USING (true);
CREATE POLICY "Admins manage routes" ON public.routes FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Bookings
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  route_id UUID NOT NULL REFERENCES public.routes(id) ON DELETE CASCADE,
  passenger_name TEXT NOT NULL,
  passenger_email TEXT NOT NULL,
  passenger_phone TEXT NOT NULL,
  passengers JSONB NOT NULL DEFAULT '[]'::JSONB,
  seats INTEGER[] NOT NULL,
  total_amount NUMERIC(10,2) NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING','SUCCESS','FAILED')),
  razorpay_order_id TEXT,
  razorpay_payment_id TEXT,
  razorpay_signature TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_bookings_route ON public.bookings(route_id);
CREATE INDEX idx_bookings_user ON public.bookings(user_id);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Public can read booked seats per route (needed for availability) - but we expose only seats+route via a view or by select
CREATE POLICY "Public can view confirmed seats" ON public.bookings FOR SELECT USING (payment_status = 'SUCCESS');
CREATE POLICY "Users view own bookings" ON public.bookings FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins view all bookings" ON public.bookings FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Anyone can create booking" ON public.bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Users update own pending bookings" ON public.bookings FOR UPDATE USING (auth.uid() = user_id OR user_id IS NULL);
CREATE POLICY "Admins manage bookings" ON public.bookings FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Auto-update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_buses_updated BEFORE UPDATE ON public.buses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_routes_updated BEFORE UPDATE ON public.routes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_bookings_updated BEFORE UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed sample data
INSERT INTO public.buses (id, name, operator, bus_type, total_seats, amenities) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Volvo Multi-Axle', 'VRL Travels', 'AC Sleeper', 36, ARRAY['WiFi','Charging Point','Blanket','Water Bottle']),
  ('22222222-2222-2222-2222-222222222222', 'Mercedes Benz', 'Orange Tours', 'AC Seater', 40, ARRAY['WiFi','Charging Point','Snacks']),
  ('33333333-3333-3333-3333-333333333333', 'Scania Metrolink', 'SRS Travels', 'AC Sleeper', 32, ARRAY['WiFi','Charging Point','Blanket','Movie']),
  ('44444444-4444-4444-4444-444444444444', 'Bharat Benz', 'Kallada Travels', 'Non-AC Seater', 44, ARRAY['Charging Point']),
  ('55555555-5555-5555-5555-555555555555', 'Volvo B11R', 'Parveen Travels', 'AC Sleeper', 36, ARRAY['WiFi','Charging Point','Blanket','Water Bottle','Snacks']);

-- Seed routes for the next 14 days for popular Indian routes
DO $$
DECLARE
  d DATE;
  routes_data RECORD;
BEGIN
  FOR d IN SELECT generate_series(CURRENT_DATE, CURRENT_DATE + INTERVAL '14 days', INTERVAL '1 day')::DATE LOOP
    -- Mumbai → Pune
    INSERT INTO public.routes (bus_id, source, destination, departure_time, arrival_time, duration_minutes, price, travel_date) VALUES
      ('11111111-1111-1111-1111-111111111111', 'Mumbai', 'Pune', '06:00', '09:30', 210, 550, d),
      ('22222222-2222-2222-2222-222222222222', 'Mumbai', 'Pune', '14:00', '17:30', 210, 450, d),
      ('33333333-3333-3333-3333-333333333333', 'Mumbai', 'Pune', '22:30', '02:00', 210, 650, d);
    -- Delhi → Jaipur
    INSERT INTO public.routes (bus_id, source, destination, departure_time, arrival_time, duration_minutes, price, travel_date) VALUES
      ('11111111-1111-1111-1111-111111111111', 'Delhi', 'Jaipur', '07:00', '12:30', 330, 850, d),
      ('44444444-4444-4444-4444-444444444444', 'Delhi', 'Jaipur', '23:00', '05:00', 360, 600, d);
    -- Bangalore → Chennai
    INSERT INTO public.routes (bus_id, source, destination, departure_time, arrival_time, duration_minutes, price, travel_date) VALUES
      ('33333333-3333-3333-3333-333333333333', 'Bangalore', 'Chennai', '21:00', '04:30', 450, 950, d),
      ('55555555-5555-5555-5555-555555555555', 'Bangalore', 'Chennai', '22:30', '06:00', 450, 1100, d);
    -- Hyderabad → Bangalore
    INSERT INTO public.routes (bus_id, source, destination, departure_time, arrival_time, duration_minutes, price, travel_date) VALUES
      ('11111111-1111-1111-1111-111111111111', 'Hyderabad', 'Bangalore', '20:00', '06:00', 600, 1200, d);
    -- Pune → Mumbai (return)
    INSERT INTO public.routes (bus_id, source, destination, departure_time, arrival_time, duration_minutes, price, travel_date) VALUES
      ('22222222-2222-2222-2222-222222222222', 'Pune', 'Mumbai', '08:00', '11:30', 210, 500, d),
      ('11111111-1111-1111-1111-111111111111', 'Pune', 'Mumbai', '18:00', '21:30', 210, 550, d);
  END LOOP;
END $$;