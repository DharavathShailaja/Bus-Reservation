DROP POLICY IF EXISTS "Anyone can create booking" ON public.bookings;
DROP POLICY IF EXISTS "Users update own pending bookings" ON public.bookings;

-- Insert: must start as PENDING; user_id must match auth.uid() OR be NULL (guest)
CREATE POLICY "Create booking with valid ownership"
ON public.bookings FOR INSERT
WITH CHECK (
  payment_status = 'PENDING'
  AND (
    (auth.uid() IS NOT NULL AND user_id = auth.uid())
    OR (auth.uid() IS NULL AND user_id IS NULL)
  )
);

-- Update: only the owning user can update their own bookings, and cannot change user_id or seats after creation via client
-- Payment confirmation happens via service role in edge function
CREATE POLICY "Users update own bookings"
ON public.bookings FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);