import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import BusList from "./pages/BusList.tsx";
import SeatSelection from "./pages/SeatSelection.tsx";
import PassengerDetails from "./pages/PassengerDetails.tsx";
import Payment from "./pages/Payment.tsx";
import Confirmation from "./pages/Confirmation.tsx";
import Auth from "./pages/Auth.tsx";
import MyBookings from "./pages/MyBookings.tsx";
import AdminLayout from "./components/admin/AdminLayout.tsx";
import AdminDashboard from "./pages/admin/Dashboard.tsx";
import AdminPassengers from "./pages/admin/Passengers.tsx";
import AdminBookings from "./pages/admin/Bookings.tsx";
import AdminBuses from "./pages/admin/Buses.tsx";
import AdminRoutes from "./pages/admin/Routes.tsx";
import AdminAnalytics from "./pages/admin/Analytics.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner position="top-center" richColors />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/buses" element={<BusList />} />
            <Route path="/seats/:routeId" element={<SeatSelection />} />
            <Route path="/passengers/:routeId" element={<PassengerDetails />} />
            <Route path="/payment/:bookingId" element={<Payment />} />
            <Route path="/confirmation/:bookingId" element={<Confirmation />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/my-bookings" element={<MyBookings />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="passengers" element={<AdminPassengers />} />
              <Route path="bookings" element={<AdminBookings />} />
              <Route path="buses" element={<AdminBuses />} />
              <Route path="routes" element={<AdminRoutes />} />
              <Route path="analytics" element={<AdminAnalytics />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;
