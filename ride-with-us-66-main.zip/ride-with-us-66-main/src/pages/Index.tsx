import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { SearchForm } from "@/components/SearchForm";
import { ShieldCheck, Clock, Tag, Headphones } from "lucide-react";
import heroBus from "@/assets/hero-bus.jpg";

const POPULAR = [
  { from: "Mumbai", to: "Pune" },
  { from: "Delhi", to: "Jaipur" },
  { from: "Bangalore", to: "Chennai" },
  { from: "Hyderabad", to: "Bangalore" },
  { from: "Pune", to: "Mumbai" },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>BusGo — Book Bus Tickets Online | Best Prices Across India</title>
        <meta name="description" content="Book bus tickets online with instant confirmation. Choose AC sleeper, seater & luxury buses. Real-time seat selection and secure payments." />
        <link rel="canonical" href="/" />
      </Helmet>

      <Header />

      <section className="relative">
        <div className="absolute inset-0">
          <img src={heroBus} alt="Bus on highway at sunset" className="h-full w-full object-cover" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-overlay" />
        </div>

        <div className="container-app relative pt-12 pb-20 sm:pt-16 sm:pb-28">
          <div className="max-w-2xl text-primary-foreground animate-fade-in">
            <h1 className="text-3xl sm:text-5xl font-extrabold leading-tight">
              India's #1 platform to book <span className="text-accent">bus tickets</span>
            </h1>
            <p className="mt-3 text-base sm:text-lg text-primary-foreground/90">
              Trusted by millions. Real-time seat selection, secure payments, instant confirmation.
            </p>
          </div>

          <div className="mt-8 animate-slide-up">
            <SearchForm />
          </div>
        </div>
      </section>

      <section className="container-app py-12 sm:py-16">
        <h2 className="text-2xl font-bold mb-6">Popular routes</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {POPULAR.map((r) => (
            <a
              key={`${r.from}-${r.to}`}
              href={`/buses?from=${r.from}&to=${r.to}&date=${new Date().toISOString().slice(0, 10)}`}
              className="rounded-xl border border-border bg-card p-4 hover:border-primary hover:shadow-card transition-all group"
            >
              <div className="text-sm text-muted-foreground">{r.from}</div>
              <div className="font-semibold text-foreground group-hover:text-primary transition-colors">→ {r.to}</div>
            </a>
          ))}
        </div>
      </section>

      <section className="bg-secondary py-12 sm:py-16">
        <div className="container-app">
          <h2 className="text-2xl font-bold mb-8 text-center">Why book with BusGo?</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: ShieldCheck, title: "Secure payments", desc: "256-bit encrypted Razorpay checkout" },
              { icon: Clock, title: "Instant confirmation", desc: "Tickets in your inbox in seconds" },
              { icon: Tag, title: "Best prices", desc: "Lowest fares guaranteed" },
              { icon: Headphones, title: "24/7 support", desc: "We're here whenever you need us" },
            ].map((f) => (
              <div key={f.title} className="text-center p-4">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary-light text-primary">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8">
        <div className="container-app text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} BusGo. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Index;
