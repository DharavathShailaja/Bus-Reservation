import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

declare global { interface Window { Razorpay: any } }

const Payment = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const navigate = useNavigate();
  const [booking, setBooking] = useState<any>(null);
  const [paying, setPaying] = useState(false);

  useEffect(() => {
    if (!bookingId) return;
    supabase.from("bookings").select("*, route:routes(*, bus:buses(*))").eq("id", bookingId).maybeSingle()
      .then(({ data }) => {
        if (!data) { toast.error("Booking not found"); navigate("/"); return; }
        if (data.payment_status === "SUCCESS") { navigate(`/confirmation/${data.id}`); return; }
        setBooking(data);
      });
  }, [bookingId, navigate]);

  const handlePay = async () => {
    if (!booking) return;
    setPaying(true);
    try {
      const { data, error } = await supabase.functions.invoke("create-razorpay-order", {
        body: { booking_id: booking.id },
      });
      if (error) throw new Error(error.message);
      if (data.error) throw new Error(data.error);

      const options = {
        key: data.key_id,
        amount: data.amount,
        currency: data.currency,
        name: "BusGo",
        description: `${booking.route.source} → ${booking.route.destination}`,
        order_id: data.order_id,
        prefill: {
          name: booking.passenger_name,
          email: booking.passenger_email,
          contact: booking.passenger_phone,
        },
        theme: { color: "#d84e55" },
        handler: async (response: any) => {
          try {
            const { data: verify, error: vErr } = await supabase.functions.invoke("verify-razorpay-payment", {
              body: {
                booking_id: booking.id,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              },
            });
            if (vErr || verify?.error) throw new Error(verify?.error ?? vErr?.message);
            toast.success("Payment successful!");
            navigate(`/confirmation/${booking.id}`);
          } catch (e: any) {
            toast.error(e.message ?? "Payment verification failed");
            setPaying(false);
          }
        },
        modal: {
          ondismiss: () => { setPaying(false); toast.info("Payment cancelled"); },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on("payment.failed", (resp: any) => {
        toast.error(resp.error?.description ?? "Payment failed");
        setPaying(false);
      });
      rzp.open();
    } catch (e: any) {
      toast.error(e.message ?? "Could not start payment");
      setPaying(false);
    }
  };

  if (!booking) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>Payment | BusGo</title></Helmet>
      <Header />
      <main className="container-app py-6 max-w-3xl">
        <h1 className="text-2xl font-bold mb-4">Confirm & Pay</h1>

        <div className="rounded-xl bg-card border border-border p-5 mb-4">
          <h2 className="font-semibold mb-3">Booking summary</h2>
          <dl className="grid grid-cols-2 gap-y-2 text-sm">
            <dt className="text-muted-foreground">Operator</dt><dd>{booking.route.bus.operator}</dd>
            <dt className="text-muted-foreground">Bus type</dt><dd>{booking.route.bus.bus_type}</dd>
            <dt className="text-muted-foreground">Route</dt><dd>{booking.route.source} → {booking.route.destination}</dd>
            <dt className="text-muted-foreground">Date</dt><dd>{booking.route.travel_date}</dd>
            <dt className="text-muted-foreground">Seats</dt><dd>{booking.seats.join(", ")}</dd>
            <dt className="text-muted-foreground">Passengers</dt><dd>{booking.passengers.length}</dd>
            <dt className="text-muted-foreground">Contact</dt><dd className="truncate">{booking.passenger_email}</dd>
          </dl>
          <div className="border-t mt-4 pt-3 flex justify-between font-bold text-lg">
            <span>Amount payable</span><span className="text-primary">₹{Number(booking.total_amount).toFixed(0)}</span>
          </div>
        </div>

        <Button onClick={handlePay} disabled={paying} size="lg" className="w-full bg-primary hover:bg-primary-dark gap-2">
          {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
          {paying ? "Processing..." : `Pay ₹${Number(booking.total_amount).toFixed(0)} with Razorpay`}
        </Button>
        <p className="text-xs text-muted-foreground text-center mt-3 flex items-center justify-center gap-1">
          <ShieldCheck className="h-3 w-3" /> Secured by Razorpay • 256-bit SSL encrypted
        </p>
      </main>
    </div>
  );
};

export default Payment;
