import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, Search, Loader2 } from "lucide-react";

type Row = {
  name: string; phone: string; email: string;
  travelDate: string; route: string; busName: string; seats: string; bookingId: string;
};

const PAGE = 10;

const Passengers = () => {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [q, setQ] = useState("");
  const [date, setDate] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("bookings")
        .select("id, passenger_name, passenger_email, passenger_phone, passengers, seats, route:routes(source, destination, travel_date, bus:buses(name, operator))")
        .eq("payment_status", "SUCCESS")
        .order("created_at", { ascending: false });
      const out: Row[] = [];
      (data ?? []).forEach((b: any) => {
        const route = `${b.route?.source ?? ""} → ${b.route?.destination ?? ""}`;
        const busName = `${b.route?.bus?.operator ?? ""} ${b.route?.bus?.name ?? ""}`.trim();
        const list: any[] = Array.isArray(b.passengers) && b.passengers.length ? b.passengers : [{
          name: b.passenger_name, phone: b.passenger_phone, email: b.passenger_email,
        }];
        list.forEach((p, i) => out.push({
          name: p.name ?? b.passenger_name, phone: p.phone ?? b.passenger_phone, email: p.email ?? b.passenger_email ?? "",
          travelDate: b.route?.travel_date ?? "", route, busName, seats: String(b.seats[i] ?? b.seats.join(",")), bookingId: b.id.slice(0, 8),
        }));
      });
      setRows(out);
    })();
  }, []);

  const filtered = useMemo(() => {
    if (!rows) return [];
    const term = q.toLowerCase().trim();
    return rows.filter(r =>
      (!term || r.name.toLowerCase().includes(term) || r.phone.includes(term) || r.email.toLowerCase().includes(term) || r.route.toLowerCase().includes(term)) &&
      (!date || r.travelDate === date)
    );
  }, [rows, q, date]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const paged = filtered.slice((page - 1) * PAGE, page * PAGE);

  const exportCSV = () => {
    const header = ["Name", "Phone", "Email", "Travel Date", "Route", "Bus", "Seat", "Booking"];
    const csv = [header, ...filtered.map(r => [r.name, r.phone, r.email, r.travelDate, r.route, r.busName, r.seats, r.bookingId])]
      .map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `passengers-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold">Passengers</h1>
          <p className="text-sm text-muted-foreground">All confirmed travellers across bookings.</p>
        </div>
        <Button onClick={exportCSV} className="gap-1" variant="outline" disabled={!filtered.length}>
          <Download className="h-4 w-4" /> Export CSV
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Filters</CardTitle>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search name, phone, email, route..." value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="pl-9" />
          </div>
          <Input type="date" value={date} onChange={(e) => { setDate(e.target.value); setPage(1); }} />
          <div className="text-sm text-muted-foreground self-center">Showing {filtered.length} passengers</div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-auto">
          {!rows ? (
            <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead className="hidden md:table-cell">Email</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="hidden md:table-cell">Route</TableHead>
                  <TableHead className="hidden lg:table-cell">Bus</TableHead>
                  <TableHead>Seat</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((r, i) => (
                  <TableRow key={i}>
                    <TableCell className="font-medium">{r.name}</TableCell>
                    <TableCell>{r.phone}</TableCell>
                    <TableCell className="hidden md:table-cell text-muted-foreground">{r.email || "—"}</TableCell>
                    <TableCell>{r.travelDate}</TableCell>
                    <TableCell className="hidden md:table-cell">{r.route}</TableCell>
                    <TableCell className="hidden lg:table-cell text-muted-foreground">{r.busName}</TableCell>
                    <TableCell><span className="font-mono">{r.seats}</span></TableCell>
                  </TableRow>
                ))}
                {paged.length === 0 && (
                  <TableRow><TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-8">No passengers found</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">Page {page} of {totalPages}</span>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>Previous</Button>
          <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>Next</Button>
        </div>
      </div>
    </div>
  );
};

export default Passengers;
