import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Ticket, Bus as BusIcon, Armchair, IndianRupee, Loader2 } from "lucide-react";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

type Stats = {
  passengers: number;
  bookings: number;
  seatsBooked: number;
  seatsTotal: number;
  revenue: number;
  perDay: { date: string; bookings: number }[];
  status: { name: string; value: number }[];
};

const COLORS = ["hsl(var(--success))", "hsl(var(--destructive))", "hsl(var(--muted-foreground))"];

const Dashboard = () => {
  const [s, setS] = useState<Stats | null>(null);

  useEffect(() => {
    (async () => {
      const [{ data: bookings }, { data: buses }, { data: routes }] = await Promise.all([
        supabase.from("bookings").select("seats, passengers, total_amount, payment_status, created_at"),
        supabase.from("buses").select("total_seats"),
        supabase.from("routes").select("id"),
      ]);
      const success = (bookings ?? []).filter(b => b.payment_status === "SUCCESS");
      const passengers = success.reduce((n, b) => n + (Array.isArray(b.passengers) ? (b.passengers as any[]).length : b.seats.length), 0);
      const seatsBooked = success.reduce((n, b) => n + b.seats.length, 0);
      const seatsTotal = (routes?.length ?? 0) * ((buses?.[0]?.total_seats) ?? 36);
      const revenue = success.reduce((n, b) => n + Number(b.total_amount), 0);

      const map = new Map<string, number>();
      success.forEach(b => {
        const d = new Date(b.created_at).toISOString().slice(0, 10);
        map.set(d, (map.get(d) ?? 0) + 1);
      });
      const perDay = Array.from(map.entries()).sort().slice(-7).map(([date, bookings]) => ({ date: date.slice(5), bookings }));

      const status = ["SUCCESS", "FAILED", "PENDING"].map(k => ({
        name: k, value: (bookings ?? []).filter(b => b.payment_status === k).length,
      })).filter(x => x.value > 0);

      setS({ passengers, bookings: success.length, seatsBooked, seatsTotal, revenue, perDay, status });
    })();
  }, []);

  if (!s) return <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;

  const cards = [
    { label: "Passengers", value: s.passengers, icon: Users, tone: "text-primary" },
    { label: "Bookings", value: s.bookings, icon: Ticket, tone: "text-success" },
    { label: "Seats Booked", value: s.seatsBooked, icon: Armchair, tone: "text-accent" },
    { label: "Seats Available", value: Math.max(s.seatsTotal - s.seatsBooked, 0), icon: BusIcon, tone: "text-muted-foreground" },
    { label: "Revenue", value: `₹${s.revenue.toLocaleString("en-IN")}`, icon: IndianRupee, tone: "text-primary" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Overview</h1>
        <p className="text-sm text-muted-foreground">Snapshot of bookings, passengers and revenue.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardHeader className="flex flex-row items-center justify-between p-4 pb-1 space-y-0">
              <CardTitle className="text-xs font-medium text-muted-foreground">{c.label}</CardTitle>
              <c.icon className={`h-4 w-4 ${c.tone}`} />
            </CardHeader>
            <CardContent className="p-4 pt-0">
              <div className="text-xl sm:text-2xl font-bold">{c.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Bookings (last 7 days)</CardTitle></CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={s.perDay}>
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Bar dataKey="bookings" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Payment status</CardTitle></CardHeader>
          <CardContent className="h-64">
            {s.status.length === 0 ? (
              <div className="flex items-center justify-center h-full text-sm text-muted-foreground">No bookings yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={s.status} dataKey="value" nameKey="name" outerRadius={80} label>
                    {s.status.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Legend />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
