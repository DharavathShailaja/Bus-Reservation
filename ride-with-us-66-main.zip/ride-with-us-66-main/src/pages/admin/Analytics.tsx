import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from "recharts";
import { Loader2 } from "lucide-react";

const Analytics = () => {
  const [perDay, setPerDay] = useState<{ date: string; bookings: number; revenue: number }[] | null>(null);
  const [occupancy, setOccupancy] = useState<{ name: string; booked: number; available: number }[]>([]);

  useEffect(() => {
    (async () => {
      const { data: bookings } = await supabase
        .from("bookings")
        .select("seats, total_amount, payment_status, created_at, route:routes(bus_id, bus:buses(name, operator, total_seats))");

      const success = (bookings ?? []).filter((b: any) => b.payment_status === "SUCCESS");

      const dayMap = new Map<string, { bookings: number; revenue: number }>();
      success.forEach((b: any) => {
        const d = new Date(b.created_at).toISOString().slice(0, 10);
        const cur = dayMap.get(d) ?? { bookings: 0, revenue: 0 };
        cur.bookings += 1;
        cur.revenue += Number(b.total_amount);
        dayMap.set(d, cur);
      });
      setPerDay(Array.from(dayMap.entries()).sort().slice(-14).map(([date, v]) => ({ date: date.slice(5), ...v })));

      const busMap = new Map<string, { name: string; booked: number; total: number }>();
      success.forEach((b: any) => {
        const id = b.route?.bus_id; if (!id) return;
        const name = `${b.route?.bus?.operator ?? ""} ${b.route?.bus?.name ?? ""}`.trim();
        const total = b.route?.bus?.total_seats ?? 36;
        const cur = busMap.get(id) ?? { name, booked: 0, total };
        cur.booked += b.seats.length;
        busMap.set(id, cur);
      });
      setOccupancy(Array.from(busMap.values()).sort((a, b) => b.booked - a.booked).slice(0, 10).map(v => ({
        name: v.name, booked: v.booked, available: Math.max(v.total - v.booked, 0),
      })));
    })();
  }, []);

  if (!perDay) return <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-sm text-muted-foreground">Booking trends and seat occupancy.</p>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Bookings &amp; revenue (14 days)</CardTitle></CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={perDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis yAxisId="l" stroke="hsl(var(--muted-foreground))" fontSize={12} allowDecimals={false} />
              <YAxis yAxisId="r" orientation="right" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
              <Legend />
              <Line yAxisId="l" type="monotone" dataKey="bookings" stroke="hsl(var(--primary))" strokeWidth={2} />
              <Line yAxisId="r" type="monotone" dataKey="revenue" stroke="hsl(var(--accent))" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Seat occupancy by bus (top 10)</CardTitle></CardHeader>
        <CardContent className="h-80">
          {occupancy.length === 0 ? (
            <div className="flex items-center justify-center h-full text-sm text-muted-foreground">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={occupancy} layout="vertical" margin={{ left: 80 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} width={140} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Legend />
                <Bar dataKey="booked" stackId="a" fill="hsl(var(--primary))" />
                <Bar dataKey="available" stackId="a" fill="hsl(var(--muted))" />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;
