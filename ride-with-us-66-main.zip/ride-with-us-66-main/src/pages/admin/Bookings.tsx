import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, XCircle, Search } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLOR: Record<string, string> = {
  SUCCESS: "text-success", FAILED: "text-destructive", PENDING: "text-muted-foreground", CANCELLED: "text-destructive",
};

const Bookings = () => {
  const [rows, setRows] = useState<any[] | null>(null);
  const [q, setQ] = useState("");
  const [date, setDate] = useState("");
  const [status, setStatus] = useState("");

  const load = async () => {
    setRows(null);
    const { data } = await supabase
      .from("bookings")
      .select("*, route:routes(source, destination, travel_date)")
      .order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    return (rows ?? []).filter(b =>
      (!q || b.passenger_name.toLowerCase().includes(q.toLowerCase()) || b.passenger_phone.includes(q) || b.id.startsWith(q)) &&
      (!date || b.route?.travel_date === date) &&
      (!status || b.payment_status === status)
    );
  }, [rows, q, date, status]);

  const cancel = async (id: string) => {
    if (!confirm("Cancel this booking? Seats will be freed.")) return;
    const { error } = await supabase.from("bookings").update({ payment_status: "CANCELLED" }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Booking cancelled"); load(); }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Bookings</h1>
        <p className="text-sm text-muted-foreground">View, filter, and cancel bookings.</p>
      </div>

      <Card>
        <CardContent className="grid sm:grid-cols-4 gap-3 p-4">
          <div className="relative sm:col-span-2">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search name, phone, booking id..." value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
          </div>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All statuses</option>
            <option value="SUCCESS">Success</option>
            <option value="PENDING">Pending</option>
            <option value="FAILED">Failed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-auto">
          {!rows ? <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div> : (
            <Table>
              <TableHeader><TableRow>
                <TableHead>ID</TableHead><TableHead>Passenger</TableHead>
                <TableHead className="hidden md:table-cell">Route</TableHead>
                <TableHead>Date</TableHead><TableHead>Seats</TableHead>
                <TableHead>Amount</TableHead><TableHead>Status</TableHead><TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {filtered.map((b) => (
                  <TableRow key={b.id}>
                    <TableCell className="font-mono text-xs">#{b.id.slice(0, 8)}</TableCell>
                    <TableCell>
                      <div className="font-medium">{b.passenger_name}</div>
                      <div className="text-xs text-muted-foreground">{b.passenger_phone}</div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{b.route?.source} → {b.route?.destination}</TableCell>
                    <TableCell>{b.route?.travel_date ?? "—"}</TableCell>
                    <TableCell className="font-mono">{b.seats.join(",")}</TableCell>
                    <TableCell>₹{Number(b.total_amount).toLocaleString("en-IN")}</TableCell>
                    <TableCell><span className={`text-xs font-semibold ${STATUS_COLOR[b.payment_status] ?? ""}`}>{b.payment_status}</span></TableCell>
                    <TableCell>
                      {b.payment_status === "SUCCESS" && (
                        <Button variant="ghost" size="sm" onClick={() => cancel(b.id)} className="gap-1 text-destructive hover:text-destructive">
                          <XCircle className="h-4 w-4" /><span className="hidden sm:inline">Cancel</span>
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow><TableCell colSpan={8} className="text-center text-sm text-muted-foreground py-8">No bookings</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Bookings;
