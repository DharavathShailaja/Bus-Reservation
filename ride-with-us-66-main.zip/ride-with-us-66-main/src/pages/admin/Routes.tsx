import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";

const RoutesPage = () => {
  const [buses, setBuses] = useState<any[]>([]);
  const [routes, setRoutes] = useState<any[] | null>(null);
  const [f, setF] = useState({ bus_id: "", source: "", destination: "", departure_time: "08:00", arrival_time: "12:00", duration_minutes: 240, price: 500, travel_date: new Date().toISOString().slice(0, 10) });

  const load = async () => {
    const [b, r] = await Promise.all([
      supabase.from("buses").select("id, name, operator").order("operator"),
      supabase.from("routes").select("*, bus:buses(name, operator)").order("travel_date").order("departure_time"),
    ]);
    setBuses(b.data ?? []);
    setRoutes(r.data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.bus_id) return toast.error("Select a bus");
    const { error } = await supabase.from("routes").insert(f);
    if (error) return toast.error(error.message);
    toast.success("Route added"); load();
  };

  const del = async (id: string) => {
    if (!confirm("Delete route?")) return;
    const { error } = await supabase.from("routes").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); load(); }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Routes</h1>
        <p className="text-sm text-muted-foreground">Schedule trips with date, timing and pricing.</p>
      </div>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base">Add route</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={submit} className="grid sm:grid-cols-4 gap-3 items-end">
            <div className="sm:col-span-2"><Label>Bus</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={f.bus_id} onChange={(e) => setF({ ...f, bus_id: e.target.value })} required>
                <option value="">Select bus...</option>
                {buses.map(b => <option key={b.id} value={b.id}>{b.operator} — {b.name}</option>)}
              </select>
            </div>
            <div><Label>From</Label><Input value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} required /></div>
            <div><Label>To</Label><Input value={f.destination} onChange={(e) => setF({ ...f, destination: e.target.value })} required /></div>
            <div><Label>Date</Label><Input type="date" value={f.travel_date} onChange={(e) => setF({ ...f, travel_date: e.target.value })} required /></div>
            <div><Label>Departure</Label><Input type="time" value={f.departure_time} onChange={(e) => setF({ ...f, departure_time: e.target.value })} required /></div>
            <div><Label>Arrival</Label><Input type="time" value={f.arrival_time} onChange={(e) => setF({ ...f, arrival_time: e.target.value })} required /></div>
            <div><Label>Price (₹)</Label><Input type="number" value={f.price} onChange={(e) => setF({ ...f, price: Number(e.target.value) })} required /></div>
            <Button type="submit" className="bg-primary hover:bg-primary/90 gap-1"><Plus className="h-4 w-4" />Add Route</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-auto">
          {!routes ? <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div> : (
            <Table>
              <TableHeader><TableRow>
                <TableHead>Route</TableHead><TableHead>Bus</TableHead><TableHead>Date</TableHead><TableHead>Time</TableHead><TableHead>Price</TableHead><TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {routes.map(r => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.source} → {r.destination}</TableCell>
                    <TableCell className="text-muted-foreground">{r.bus?.operator} {r.bus?.name}</TableCell>
                    <TableCell>{r.travel_date}</TableCell>
                    <TableCell>{r.departure_time}</TableCell>
                    <TableCell>₹{r.price}</TableCell>
                    <TableCell><Button variant="ghost" size="icon" onClick={() => del(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
                  </TableRow>
                ))}
                {routes.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-sm text-muted-foreground py-8">No routes yet</TableCell></TableRow>}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RoutesPage;
