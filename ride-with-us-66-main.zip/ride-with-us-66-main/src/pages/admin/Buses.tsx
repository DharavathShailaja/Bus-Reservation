import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";

const Buses = () => {
  const [buses, setBuses] = useState<any[] | null>(null);
  const [f, setF] = useState({ name: "", operator: "", bus_type: "AC Sleeper", total_seats: 36, amenities: "WiFi,Charging Point" });

  const load = async () => {
    const { data } = await supabase.from("buses").select("*").order("created_at", { ascending: false });
    setBuses(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("buses").insert({
      name: f.name, operator: f.operator, bus_type: f.bus_type, total_seats: Number(f.total_seats),
      amenities: f.amenities.split(",").map(s => s.trim()).filter(Boolean),
    });
    if (error) return toast.error(error.message);
    toast.success("Bus added");
    setF({ name: "", operator: "", bus_type: "AC Sleeper", total_seats: 36, amenities: "WiFi,Charging Point" });
    load();
  };

  const del = async (id: string) => {
    if (!confirm("Delete this bus? Routes using it will fail.")) return;
    const { error } = await supabase.from("buses").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); load(); }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Buses</h1>
        <p className="text-sm text-muted-foreground">Add or remove fleet vehicles.</p>
      </div>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-base">Add new bus</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={submit} className="grid sm:grid-cols-5 gap-3 items-end">
            <div><Label>Name</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required /></div>
            <div><Label>Operator</Label><Input value={f.operator} onChange={(e) => setF({ ...f, operator: e.target.value })} required /></div>
            <div><Label>Type</Label><Input value={f.bus_type} onChange={(e) => setF({ ...f, bus_type: e.target.value })} required /></div>
            <div><Label>Seats</Label><Input type="number" value={f.total_seats} onChange={(e) => setF({ ...f, total_seats: Number(e.target.value) })} required /></div>
            <Button type="submit" className="bg-primary hover:bg-primary/90 gap-1"><Plus className="h-4 w-4" />Add</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-auto">
          {!buses ? <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div> : (
            <Table>
              <TableHeader><TableRow>
                <TableHead>Operator</TableHead><TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead>Seats</TableHead><TableHead></TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {buses.map(b => (
                  <TableRow key={b.id}>
                    <TableCell className="font-medium">{b.operator}</TableCell>
                    <TableCell>{b.name}</TableCell>
                    <TableCell className="text-muted-foreground">{b.bus_type}</TableCell>
                    <TableCell>{b.total_seats}</TableCell>
                    <TableCell><Button variant="ghost" size="icon" onClick={() => del(b.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
                  </TableRow>
                ))}
                {buses.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-8">No buses yet</TableCell></TableRow>}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Buses;
