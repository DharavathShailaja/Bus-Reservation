import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, ChevronLeft } from "lucide-react";
import { format, parse } from "date-fns";
import { toast } from "sonner";

const formatTime = (t: string) => { try { return format(parse(t, "HH:mm:ss", new Date()), "HH:mm"); } catch { return t; } };

const SeatSelection = () => {
  const { routeId } = useParams<{ routeId: string }>();
  const navigate = useNavigate();
  const [route, setRoute] = useState<any>(null);
  const [bookedSeats, setBookedSeats] = useState<Set<number>>(new Set());
  const [selected, setSelected] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!routeId) return;
    const load = async () => {
      const { data: r } = await supabase.from("routes").select("*, bus:buses(*)").eq("id", routeId).maybeSingle();
      if (!r) { setLoading(false); return; }
      setRoute(r);
      const { data: bs } = await supabase.from("bookings").select("seats").eq("route_id", routeId).eq("payment_status", "SUCCESS");
      const set = new Set<number>();
      (bs ?? []).forEach((b: any) => (b.seats ?? []).forEach((s: number) => set.add(s)));
      setBookedSeats(set);
      setLoading(false);
    };
    load();

    // Realtime updates
    const channel = supabase.channel(`route-${routeId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "bookings", filter: `route_id=eq.${routeId}` },
        () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [routeId]);

  const toggleSeat = (n: number) => {
    if (bookedSeats.has(n)) return;
    setSelected((prev) => prev.includes(n) ? prev.filter((s) => s !== n) : prev.length >= 6 ? (toast.error("Max 6 seats"), prev) : [...prev, n]);
  };

  const proceed = () => {
    if (selected.length === 0) { toast.error("Please select at least one seat"); return; }
    sessionStorage.setItem("pending_booking", JSON.stringify({ routeId, seats: selected, totalAmount: selected.length * Number(route.price) }));
    navigate(`/passengers/${routeId}`);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!route) return <div className="min-h-screen flex items-center justify-center"><p>Route not found</p></div>;

  // Sleeper layout: lower deck (rows of 2+1) + upper deck. We'll build a simple seat grid based on total_seats.
  // For simplicity: arrange as rows of 4 seats (2 + aisle + 2) for seater, or rows of 3 (1+aisle+2) for sleeper.
  const total = route.bus.total_seats;
  const isSleeper = route.bus.bus_type.toLowerCase().includes("sleeper");
  const perRow = isSleeper ? 3 : 4;
  const rows = Math.ceil(total / perRow);

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>{`Select seats — ${route.source} to ${route.destination} | BusGo`}</title></Helmet>
      <Header />

      <div className="container-app py-4">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-3">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>

        <div className="rounded-xl bg-card border border-border p-4 mb-4">
          <h1 className="font-semibold">{route.bus.operator} • {route.bus.bus_type}</h1>
          <p className="text-sm text-muted-foreground">
            {route.source} → {route.destination} • {format(new Date(route.travel_date), "EEE, dd MMM")} • {formatTime(route.departure_time)}
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_320px] gap-4">
          <div className="rounded-xl bg-card border border-border p-4 sm:p-6">
            <div className="flex items-center justify-center gap-4 mb-5 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5"><div className="h-4 w-4 rounded border-2 border-seat-available" /> Available</div>
              <div className="flex items-center gap-1.5"><div className="h-4 w-4 rounded bg-seat-selected" /> Selected</div>
              <div className="flex items-center gap-1.5"><div className="h-4 w-4 rounded bg-seat-booked" /> Booked</div>
            </div>

            <div className="mx-auto max-w-xs sm:max-w-sm rounded-2xl border-2 border-border p-4 bg-secondary/40">
              <div className="text-center text-xs text-muted-foreground mb-3 pb-2 border-b border-dashed border-border">🚍 Driver</div>
              <div className="space-y-2">
                {Array.from({ length: rows }).map((_, rowIdx) => {
                  const seatsInRow = Array.from({ length: perRow }).map((_, i) => rowIdx * perRow + i + 1).filter((n) => n <= total);
                  return (
                    <div key={rowIdx} className={`grid gap-2 ${perRow === 4 ? "grid-cols-[1fr_1fr_12px_1fr_1fr]" : "grid-cols-[1fr_12px_1fr_1fr]"}`}>
                      {seatsInRow.slice(0, perRow === 4 ? 2 : 1).map((n) => (
                        <SeatBtn key={n} n={n} booked={bookedSeats.has(n)} selected={selected.includes(n)} onClick={() => toggleSeat(n)} />
                      ))}
                      <div />
                      {seatsInRow.slice(perRow === 4 ? 2 : 1).map((n) => (
                        <SeatBtn key={n} n={n} booked={bookedSeats.has(n)} selected={selected.includes(n)} onClick={() => toggleSeat(n)} />
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-card border border-border p-4 h-fit sticky top-20">
            <h2 className="font-semibold mb-3">Booking summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Selected seats</span><span className="font-medium">{selected.length ? selected.sort((a,b)=>a-b).join(", ") : "—"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Price per seat</span><span>₹{Number(route.price).toFixed(0)}</span></div>
              <div className="border-t border-border my-2 pt-2 flex justify-between font-bold text-base">
                <span>Total</span><span className="text-primary">₹{(selected.length * Number(route.price)).toFixed(0)}</span>
              </div>
            </div>
            <Button className="w-full mt-4 bg-primary hover:bg-primary-dark" onClick={proceed} disabled={selected.length === 0}>
              Continue
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SeatBtn = ({ n, booked, selected, onClick }: { n: number; booked: boolean; selected: boolean; onClick: () => void }) => (
  <button
    onClick={onClick} disabled={booked}
    className={`h-9 sm:h-10 rounded-md text-xs font-semibold transition-all border-2
      ${booked ? "bg-seat-booked border-seat-booked text-white cursor-not-allowed" :
        selected ? "bg-seat-selected border-seat-selected text-white scale-105" :
        "border-seat-available text-seat-available hover:bg-seat-available/10"}`}
    aria-label={`Seat ${n}`}
  >
    {n}
  </button>
);

export default SeatSelection;
