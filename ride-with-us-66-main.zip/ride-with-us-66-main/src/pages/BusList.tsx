import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { SearchForm } from "@/components/SearchForm";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Clock, Wifi, Zap, Star, Loader2 } from "lucide-react";
import { format, parse } from "date-fns";

interface RouteRow {
  id: string;
  source: string;
  destination: string;
  departure_time: string;
  arrival_time: string;
  duration_minutes: number;
  price: number;
  travel_date: string;
  bus: { id: string; name: string; operator: string; bus_type: string; total_seats: number; amenities: string[] };
  booked_seats_count: number;
}

const formatTime = (t: string) => {
  try { return format(parse(t, "HH:mm:ss", new Date()), "HH:mm"); } catch { return t; }
};
const formatDuration = (m: number) => `${Math.floor(m / 60)}h ${m % 60}m`;

const BusList = () => {
  const [params] = useSearchParams();
  const from = params.get("from") ?? "";
  const to = params.get("to") ?? "";
  const date = params.get("date") ?? "";
  const [routes, setRoutes] = useState<RouteRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("routes")
        .select("*, bus:buses(*)")
        .ilike("source", from)
        .ilike("destination", to)
        .eq("travel_date", date)
        .order("departure_time");

      if (error) { console.error(error); setLoading(false); return; }

      // Get booked counts for each route
      const ids = (data ?? []).map((r) => r.id);
      const { data: bookings } = await supabase
        .from("bookings")
        .select("route_id, seats")
        .in("route_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"])
        .eq("payment_status", "SUCCESS");

      const counts = new Map<string, number>();
      (bookings ?? []).forEach((b: any) => {
        counts.set(b.route_id, (counts.get(b.route_id) ?? 0) + (b.seats?.length ?? 0));
      });

      setRoutes((data ?? []).map((r: any) => ({ ...r, booked_seats_count: counts.get(r.id) ?? 0 })));
      setLoading(false);
    };
    if (from && to && date) load();
  }, [from, to, date]);

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet>
        <title>{`Buses from ${from} to ${to} on ${date} | BusGo`}</title>
        <meta name="description" content={`Book buses from ${from} to ${to}. Compare timings and prices.`} />
      </Helmet>
      <Header />

      <div className="bg-primary py-4">
        <div className="container-app">
          <SearchForm defaultSource={from} defaultDestination={to} defaultDate={date} />
        </div>
      </div>

      <main className="container-app py-6">
        <div className="mb-4 flex items-baseline justify-between flex-wrap gap-2">
          <h1 className="text-xl sm:text-2xl font-bold">
            {from} <span className="text-muted-foreground">→</span> {to}
          </h1>
          <p className="text-sm text-muted-foreground">
            {date && format(new Date(date), "EEE, dd MMM yyyy")} • {routes.length} buses found
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : routes.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
            <p className="text-lg font-semibold">No buses found</p>
            <p className="text-sm text-muted-foreground mt-1">Try a different date or route.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {routes.map((r) => {
              const available = r.bus.total_seats - r.booked_seats_count;
              return (
                <div key={r.id} className="rounded-xl border border-border bg-card p-4 sm:p-5 shadow-card hover:shadow-elevated transition-shadow">
                  <div className="grid sm:grid-cols-[1fr_auto] gap-4 items-center">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div>
                          <h3 className="font-semibold text-base sm:text-lg">{r.bus.operator}</h3>
                          <p className="text-xs text-muted-foreground">{r.bus.name} • {r.bus.bus_type}</p>
                        </div>
                        <div className="flex items-center gap-1 text-sm bg-success/10 text-success px-2 py-0.5 rounded">
                          <Star className="h-3 w-3 fill-current" /> 4.5
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 sm:gap-4 items-center">
                        <div>
                          <div className="text-lg sm:text-xl font-bold">{formatTime(r.departure_time)}</div>
                          <div className="text-xs text-muted-foreground">{r.source}</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                            <Clock className="h-3 w-3" />{formatDuration(r.duration_minutes)}
                          </div>
                          <div className="border-t border-dashed border-border my-1" />
                        </div>
                        <div className="text-right">
                          <div className="text-lg sm:text-xl font-bold">{formatTime(r.arrival_time)}</div>
                          <div className="text-xs text-muted-foreground">{r.destination}</div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        {r.bus.amenities?.slice(0, 4).map((a) => (
                          <Badge key={a} variant="outline" className="text-[10px] font-normal gap-1">
                            {a === "WiFi" && <Wifi className="h-3 w-3" />}
                            {a === "Charging Point" && <Zap className="h-3 w-3" />}
                            {a}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 sm:border-l sm:pl-5 sm:border-border">
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">₹{Number(r.price).toFixed(0)}</div>
                        <div className={`text-xs ${available > 5 ? "text-success" : "text-destructive"}`}>
                          {available} seats left
                        </div>
                      </div>
                      <Button asChild disabled={available === 0} className="bg-primary hover:bg-primary-dark">
                        <Link to={`/seats/${r.id}`}>{available === 0 ? "Sold out" : "View Seats"}</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};

export default BusList;
