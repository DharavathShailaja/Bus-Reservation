import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Download, Bus, Calendar, MapPin, CreditCard } from "lucide-react";

const Confirmation = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const [booking, setBooking] = useState<any>(null);

  useEffect(() => {
    if (!bookingId) return;
    supabase.from("bookings").select("*, route:routes(*, bus:buses(*))").eq("id", bookingId).maybeSingle()
      .then(({ data }) => setBooking(data));
  }, [bookingId]);

  if (!booking) return null;

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>Booking Confirmed | BusGo</title></Helmet>
      <Header />
      <main className="container-app py-8 max-w-3xl">
        <div className="text-center mb-6 animate-fade-in">
          <div className="mx-auto h-16 w-16 rounded-full bg-success/10 flex items-center justify-center mb-3">
            <CheckCircle2 className="h-10 w-10 text-success" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold">Booking Confirmed!</h1>
          <p className="text-muted-foreground mt-1">Your ticket has been sent to {booking.passenger_email}</p>
        </div>

        <div className="rounded-2xl bg-card border-2 border-dashed border-primary/40 overflow-hidden shadow-elevated">
          <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
            <div className="flex items-center gap-2"><Bus className="h-5 w-5" /><span className="font-semibold">e-Ticket</span></div>
            <span className="text-xs font-mono opacity-90">#{booking.id.slice(0, 8).toUpperCase()}</span>
          </div>

          <div className="p-5 space-y-4">
            <div>
              <h2 className="text-lg font-bold">{booking.route.bus.operator}</h2>
              <p className="text-sm text-muted-foreground">{booking.route.bus.name} • {booking.route.bus.bus_type}</p>
            </div>

            <div className="grid sm:grid-cols-3 gap-4 py-3 border-y border-border">
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <div className="text-xs text-muted-foreground">From</div>
                  <div className="font-semibold">{booking.route.source}</div>
                  <div className="text-xs">{booking.route.departure_time}</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <div className="text-xs text-muted-foreground">To</div>
                  <div className="font-semibold">{booking.route.destination}</div>
                  <div className="text-xs">{booking.route.arrival_time}</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Calendar className="h-4 w-4 text-primary mt-0.5" />
                <div>
                  <div className="text-xs text-muted-foreground">Date</div>
                  <div className="font-semibold">{booking.route.travel_date}</div>
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs text-muted-foreground mb-2">Passengers ({booking.passengers.length})</div>
              <div className="space-y-1.5">
                {booking.passengers.map((p: any, i: number) => (
                  <div key={i} className="flex justify-between text-sm bg-secondary rounded px-3 py-2">
                    <span>{p.name} ({p.age}, {p.gender})</span>
                    <span className="font-semibold">Seat {p.seat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm pt-3 border-t border-border">
              <div>
                <div className="text-xs text-muted-foreground flex items-center gap-1"><CreditCard className="h-3 w-3" /> Payment ID</div>
                <div className="font-mono text-xs break-all">{booking.razorpay_payment_id}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground">Total paid</div>
                <div className="text-xl font-bold text-primary">₹{Number(booking.total_amount).toFixed(0)}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6 justify-center">
          <Button variant="outline" onClick={() => window.print()} className="gap-2">
            <Download className="h-4 w-4" /> Print
          </Button>
          <Button asChild className="bg-primary hover:bg-primary-dark"><Link to="/">Book another</Link></Button>
        </div>
      </main>
    </div>
  );
};

export default Confirmation;
