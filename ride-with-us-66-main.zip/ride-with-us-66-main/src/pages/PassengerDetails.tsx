import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const passengerSchema = z.object({
  name: z.string().trim().min(2, "Name too short").max(60),
  age: z.coerce.number().int().min(1).max(120),
  gender: z.enum(["Male", "Female", "Other"]),
});

const contactSchema = z.object({
  email: z.string().trim().email().max(255),
  phone: z.string().trim().regex(/^[0-9]{10}$/, "Enter 10-digit phone"),
});

const PassengerDetails = () => {
  const { routeId } = useParams<{ routeId: string }>();
  const navigate = useNavigate();
  const [route, setRoute] = useState<any>(null);
  const [pending, setPending] = useState<{ seats: number[]; totalAmount: number } | null>(null);
  const [passengers, setPassengers] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("pending_booking");
    if (!raw) { navigate(-1); return; }
    const p = JSON.parse(raw);
    if (p.routeId !== routeId) { navigate(-1); return; }
    setPending({ seats: p.seats, totalAmount: p.totalAmount });
    setPassengers(p.seats.map((s: number) => ({ seat: s, name: "", age: "", gender: "Male" })));
    supabase.from("routes").select("*, bus:buses(*)").eq("id", routeId!).maybeSingle().then(({ data }) => setRoute(data));
    supabase.auth.getUser().then(({ data }) => { if (data.user?.email) setEmail(data.user.email); });
  }, [routeId, navigate]);

  const updatePassenger = (i: number, field: string, val: any) => {
    setPassengers((prev) => prev.map((p, idx) => idx === i ? { ...p, [field]: val } : p));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pending || !route) return;

    const contactCheck = contactSchema.safeParse({ email, phone });
    if (!contactCheck.success) { toast.error(contactCheck.error.issues[0].message); return; }

    for (const p of passengers) {
      const v = passengerSchema.safeParse(p);
      if (!v.success) { toast.error(`Seat ${p.seat}: ${v.error.issues[0].message}`); return; }
    }

    setSubmitting(true);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const { data: booking, error } = await supabase.from("bookings").insert({
        user_id: userData.user?.id ?? null,
        route_id: routeId!,
        passenger_name: passengers[0].name,
        passenger_email: email,
        passenger_phone: phone,
        passengers: passengers,
        seats: pending.seats,
        total_amount: pending.totalAmount,
        payment_status: "PENDING",
      }).select().single();

      if (error) throw error;
      sessionStorage.setItem("active_booking_id", booking.id);
      navigate(`/payment/${booking.id}`);
    } catch (err: any) {
      toast.error(err.message ?? "Failed to create booking");
      setSubmitting(false);
    }
  };

  if (!route || !pending) return null;

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>Passenger Details | BusGo</title></Helmet>
      <Header />
      <main className="container-app py-6">
        <h1 className="text-2xl font-bold mb-4">Passenger Details</h1>
        <form onSubmit={handleSubmit} className="grid lg:grid-cols-[1fr_320px] gap-4">
          <div className="space-y-4">
            {passengers.map((p, i) => (
              <div key={p.seat} className="rounded-xl bg-card border border-border p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold">Passenger {i + 1}</h3>
                  <span className="text-xs bg-primary-light text-primary px-2 py-1 rounded font-semibold">Seat {p.seat}</span>
                </div>
                <div className="grid sm:grid-cols-[1fr_100px_auto] gap-3">
                  <div>
                    <Label htmlFor={`n-${i}`}>Full name</Label>
                    <Input id={`n-${i}`} value={p.name} onChange={(e) => updatePassenger(i, "name", e.target.value)} required maxLength={60} />
                  </div>
                  <div>
                    <Label htmlFor={`a-${i}`}>Age</Label>
                    <Input id={`a-${i}`} type="number" min={1} max={120} value={p.age} onChange={(e) => updatePassenger(i, "age", e.target.value)} required />
                  </div>
                  <div>
                    <Label className="block mb-2">Gender</Label>
                    <RadioGroup value={p.gender} onValueChange={(v) => updatePassenger(i, "gender", v)} className="flex gap-2">
                      {["Male","Female","Other"].map((g) => (
                        <label key={g} className={`flex items-center gap-1 px-2 py-1.5 rounded border cursor-pointer text-sm ${p.gender === g ? "border-primary bg-primary-light text-primary" : "border-border"}`}>
                          <RadioGroupItem value={g} className="sr-only" /> {g[0]}
                        </label>
                      ))}
                    </RadioGroup>
                  </div>
                </div>
              </div>
            ))}

            <div className="rounded-xl bg-card border border-border p-4">
              <h3 className="font-semibold mb-3">Contact details</h3>
              <p className="text-xs text-muted-foreground mb-3">Ticket will be sent here</p>
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={255} />
                </div>
                <div>
                  <Label htmlFor="phone">Phone (10 digits)</Label>
                  <Input id="phone" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))} required />
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-card border border-border p-4 h-fit sticky top-20">
            <h2 className="font-semibold mb-3">Summary</h2>
            <div className="text-sm space-y-2">
              <div>{route.bus.operator}</div>
              <div className="text-muted-foreground text-xs">{route.source} → {route.destination}</div>
              <div className="flex justify-between"><span className="text-muted-foreground">Seats</span><span>{pending.seats.join(", ")}</span></div>
              <div className="border-t pt-2 flex justify-between font-bold"><span>Total</span><span className="text-primary">₹{pending.totalAmount.toFixed(0)}</span></div>
            </div>
            <Button type="submit" disabled={submitting} className="w-full mt-4 bg-primary hover:bg-primary-dark">
              {submitting ? "Please wait..." : "Proceed to Payment"}
            </Button>
          </div>
        </form>
      </main>
    </div>
  );
};

export default PassengerDetails;
