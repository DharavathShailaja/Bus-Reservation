import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const MyBookings = () => {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { navigate("/auth"); return; }
      const { data } = await supabase.from("bookings").select("*, route:routes(source, destination, travel_date, departure_time)").eq("user_id", user.id).order("created_at", { ascending: false });
      setBookings(data ?? []);
    })();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>My Bookings | BusGo</title></Helmet>
      <Header />
      <main className="container-app py-6">
        <h1 className="text-2xl font-bold mb-4">My Bookings</h1>
        {bookings.length === 0 ? (
          <p className="text-muted-foreground">No bookings yet. <Link to="/" className="text-primary">Book one now →</Link></p>
        ) : (
          <div className="space-y-3">
            {bookings.map((b) => (
              <div key={b.id} className="rounded-xl bg-card border border-border p-4 flex justify-between items-center">
                <div>
                  <div className="font-semibold">{b.route?.source} → {b.route?.destination}</div>
                  <div className="text-xs text-muted-foreground">{b.route?.travel_date} • Seats {b.seats.join(",")} • ₹{b.total_amount}</div>
                  <div className={`text-xs font-semibold mt-1 ${b.payment_status === "SUCCESS" ? "text-success" : b.payment_status === "FAILED" ? "text-destructive" : "text-muted-foreground"}`}>{b.payment_status}</div>
                </div>
                {b.payment_status === "SUCCESS" ? (
                  <Button asChild variant="outline" size="sm"><Link to={`/confirmation/${b.id}`}>View ticket</Link></Button>
                ) : b.payment_status === "PENDING" ? (
                  <Button asChild size="sm" className="bg-primary hover:bg-primary-dark"><Link to={`/payment/${b.id}`}>Pay now</Link></Button>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default MyBookings;
