import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { toast } from "sonner";

const schema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(6).max(72),
});

const Auth = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (mode: "login" | "signup") => {
    const v = schema.safeParse({ email, password });
    if (!v.success) { toast.error(v.error.issues[0].message); return; }
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password, options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created! You're logged in.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back!");
      }
      navigate("/");
    } catch (e: any) {
      toast.error(e.message);
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-secondary/40">
      <Helmet><title>Login | BusGo</title></Helmet>
      <Header />
      <main className="container-app py-12 max-w-md">
        <div className="rounded-xl bg-card border border-border p-6 shadow-card">
          <h1 className="text-2xl font-bold mb-1">Welcome to BusGo</h1>
          <p className="text-sm text-muted-foreground mb-5">Login or create an account to manage your bookings</p>

          <Tabs defaultValue="login">
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="signup">Sign up</TabsTrigger>
            </TabsList>

            {(["login","signup"] as const).map((mode) => (
              <TabsContent key={mode} value={mode} className="space-y-3 mt-4">
                <div>
                  <Label htmlFor={`email-${mode}`}>Email</Label>
                  <Input id={`email-${mode}`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor={`pwd-${mode}`}>Password</Label>
                  <Input id={`pwd-${mode}`} type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <Button onClick={() => handleAuth(mode)} disabled={loading} className="w-full bg-primary hover:bg-primary-dark">
                  {loading ? "Please wait..." : mode === "login" ? "Login" : "Create account"}
                </Button>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Auth;
