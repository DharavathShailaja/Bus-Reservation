import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeftRight, Calendar, MapPin, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { format, addDays } from "date-fns";

const POPULAR_CITIES = ["Mumbai", "Pune", "Delhi", "Jaipur", "Bangalore", "Chennai", "Hyderabad"];

interface Props {
  defaultSource?: string;
  defaultDestination?: string;
  defaultDate?: string;
  compact?: boolean;
}

export const SearchForm = ({ defaultSource = "", defaultDestination = "", defaultDate, compact }: Props) => {
  const [source, setSource] = useState(defaultSource);
  const [destination, setDestination] = useState(defaultDestination);
  const [date, setDate] = useState(defaultDate ?? format(new Date(), "yyyy-MM-dd"));
  const navigate = useNavigate();

  const swap = () => {
    setSource(destination);
    setDestination(source);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!source.trim() || !destination.trim() || !date) return;
    navigate(`/buses?from=${encodeURIComponent(source.trim())}&to=${encodeURIComponent(destination.trim())}&date=${date}`);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className={`grid gap-3 rounded-2xl bg-card p-4 sm:p-5 shadow-search border border-border ${
        compact ? "" : "md:grid-cols-[1fr_auto_1fr_1fr_auto]"
      }`}
    >
      <div className="space-y-1.5">
        <Label htmlFor="from" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">From</Label>
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="from" list="cities" value={source} onChange={(e) => setSource(e.target.value)}
            placeholder="Enter source" className="pl-9 h-11" required
          />
        </div>
      </div>

      <button
        type="button" onClick={swap}
        className="hidden md:flex h-11 w-11 self-end items-center justify-center rounded-full border border-border bg-background hover:bg-muted transition-colors"
        aria-label="Swap cities"
      >
        <ArrowLeftRight className="h-4 w-4" />
      </button>

      <div className="space-y-1.5">
        <Label htmlFor="to" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">To</Label>
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="to" list="cities" value={destination} onChange={(e) => setDestination(e.target.value)}
            placeholder="Enter destination" className="pl-9 h-11" required
          />
        </div>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="date" className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Date of journey</Label>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <Input
            id="date" type="date" value={date} min={format(new Date(), "yyyy-MM-dd")}
            max={format(addDays(new Date(), 14), "yyyy-MM-dd")}
            onChange={(e) => setDate(e.target.value)} className="pl-9 h-11" required
          />
        </div>
      </div>

      <Button type="submit" size="lg" className="md:self-end h-11 px-6 bg-primary hover:bg-primary-dark gap-2">
        <Search className="h-4 w-4" /> Search Buses
      </Button>

      <datalist id="cities">
        {POPULAR_CITIES.map((c) => <option key={c} value={c} />)}
      </datalist>
    </form>
  );
};
