import { useEffect, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, SidebarHeader, SidebarFooter,
} from "@/components/ui/sidebar";
import { LayoutDashboard, Users, Ticket, Bus as BusIcon, Map, BarChart3, Loader2, LogOut, Home } from "lucide-react";

const items = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard, end: true },
  { title: "Passengers", url: "/admin/passengers", icon: Users },
  { title: "Bookings", url: "/admin/bookings", icon: Ticket },
  { title: "Buses", url: "/admin/buses", icon: BusIcon },
  { title: "Routes", url: "/admin/routes", icon: Map },
  { title: "Analytics", url: "/admin/analytics", icon: BarChart3 },
];

const AdminSidebar = () => (
  <Sidebar collapsible="icon">
    <SidebarHeader className="border-b border-sidebar-border">
      <div className="flex items-center gap-2 px-2 py-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <BusIcon className="h-4 w-4" />
        </div>
        <span className="font-bold text-sidebar-foreground group-data-[collapsible=icon]:hidden">BusGo Admin</span>
      </div>
    </SidebarHeader>
    <SidebarContent>
      <SidebarGroup>
        <SidebarGroupLabel>Manage</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
            {items.map((it) => (
              <SidebarMenuItem key={it.title}>
                <SidebarMenuButton asChild tooltip={it.title}>
                  <NavLink to={it.url} end={it.end} className={({ isActive }) =>
                    isActive ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" : "hover:bg-sidebar-accent/50"
                  }>
                    <it.icon className="h-4 w-4" />
                    <span>{it.title}</span>
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    </SidebarContent>
    <SidebarFooter className="border-t border-sidebar-border">
      <SidebarMenu>
        <SidebarMenuItem>
          <SidebarMenuButton asChild tooltip="Back to site">
            <NavLink to="/"><Home className="h-4 w-4" /><span>Back to site</span></NavLink>
          </SidebarMenuButton>
        </SidebarMenuItem>
      </SidebarMenu>
    </SidebarFooter>
  </Sidebar>
);

const AdminLayout = () => {
  const navigate = useNavigate();
  const [authorized, setAuthorized] = useState<boolean | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { navigate("/auth"); return; }
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
      setAuthorized(!!data);
    })();
  }, [navigate]);

  const handleLogout = async () => { await supabase.auth.signOut(); navigate("/"); };

  if (authorized === null) return (
    <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
  );
  if (!authorized) return (
    <div className="min-h-screen bg-background">
      <main className="container-app py-12 max-w-md text-center">
        <h1 className="text-2xl font-bold mb-2">Admin access required</h1>
        <p className="text-sm text-muted-foreground mb-4">
          Your account doesn't have an admin role. Ask Lovable to grant your account admin rights.
        </p>
        <Button asChild variant="outline"><a href="/">Back to home</a></Button>
      </main>
    </div>
  );

  return (
    <SidebarProvider>
      <Helmet><title>Admin | BusGo</title></Helmet>
      <div className="min-h-screen flex w-full bg-background">
        <AdminSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 flex items-center justify-between border-b border-border px-3 sticky top-0 bg-background/95 backdrop-blur z-30">
            <div className="flex items-center gap-2">
              <SidebarTrigger />
              <span className="font-semibold text-sm">Admin Dashboard</span>
            </div>
            <div className="flex items-center gap-1">
              <ThemeToggle />
              <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-1">
                <LogOut className="h-4 w-4" /><span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default AdminLayout;
